﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyConsoleApplication
{
    public class UserMessage
    {
        string strMessage;

        public string Message
        {
            get
            {return this.strMessage;}

            set
            {this.strMessage = value;}
        }
    }

    public class  DisplayBaseClass:UserMessage
    {
       string strUser = "joe";

       public DisplayBaseClass(string Message)
        {
           this.Message= Message;
        }
       public DisplayBaseClass()
       {} 

        public string UserName
        {
            get
            {return this.strUser;}

            set
            {this.strUser = value;}
        }
  
       public void WriteToDatabase()
       {    //Instantiate Data Access Layer class
           // write User message to database
           return;
       }
    }

}
