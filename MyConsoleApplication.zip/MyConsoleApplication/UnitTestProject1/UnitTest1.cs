﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Configuration;
using MyConsoleApplication;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        DisplayBaseClass testClass = new DisplayBaseClass();

        [TestMethod]
        public void TestMethod1()
        {
            string strExpectedOutput = "Hello World";          
            Assert.AreEqual(strExpectedOutput, testClass.Message);
        }

        [TestMethod]
        public void TestMethod2()
        {
            string strExpectedOutput = "Hello World";
            testClass.Message = "Hello World";
            Assert.AreEqual(strExpectedOutput, testClass.Message);
        }

        [TestMethod]
        public void TestMethod3()
        {
            string strExpectedOutput = "joe";

            Assert.AreEqual(strExpectedOutput, testClass.UserName);

        }
    }
}
